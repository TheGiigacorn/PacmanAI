#!/bin/bash
#echo "Please modify this file to compile and run your program"
python3 main.py $1 $2
